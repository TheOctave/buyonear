<?php
//hashing
const HASH_ALGO = 'sha256';
const HASH_SALT = 'Special salty*fdf323 salt***';

//database connections
const DB_TYPE = 'mysql';
const DB_HOST = 'localhost';
const DB_NAME = 'buyonear';
const DB_USER = 'root';
const DB_PASS = '';
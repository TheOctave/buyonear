<?php
echo "bid";
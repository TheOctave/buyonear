<?php
echo "rate";
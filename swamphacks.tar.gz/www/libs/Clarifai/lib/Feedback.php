<?php

namespace Clarifai;

class Feedback {

}
?>
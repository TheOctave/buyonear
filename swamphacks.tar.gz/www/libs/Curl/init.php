<?php
require(dirname(__FILE__) . '/lib/Curl.php');
require(dirname(__FILE__) . '/lib/CaseInsensitiveArray.php');
require(dirname(__FILE__) . '/lib/MultiCurl.php');
?>